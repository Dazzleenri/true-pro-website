import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  ArrowRight, ShieldCheck, Star, Users, Map, CheckCircle2, 
  MapPin, Check, Trees, ClipboardList, Zap 
} from 'lucide-react';

import Navigation from './components/Navigation';
import InteractiveDashboard from './components/InteractiveDashboard';
import FeatureGrid from './components/FeatureGrid';
import IndustriesSection from './components/IndustriesSection';
import WorkflowSection from './components/WorkflowSection';
import CTASection from './components/CTASection';
import DemoModal from './components/DemoModal';

export default function App() {
  const [isDemoOpen, setIsDemoOpen] = useState(false);
  const [selectedIndustry, setSelectedIndustry] = useState('general');

  const openDemo = (industry: string = 'general') => {
    setSelectedIndustry(industry);
    setIsDemoOpen(true);
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const trustPoints = [
    { text: "Built for outdoor service teams", desc: "No generic office workflows" },
    { text: "Connect office and field work", desc: "All team members aligned" },
    { text: "See jobs, crews, and follow-up in one place", desc: "Complete operational clarity" },
    { text: "Designed for growing service companies", desc: "Scales with your regional depots" }
  ];

  return (
    <div className="min-h-screen bg-white" id="truepro-root">
      
      {/* Navigation Header */}
      <Navigation 
        onBookDemo={() => openDemo('general')} 
        scrollToSection={scrollToSection} 
      />

      {/* HERO SECTION */}
      <section className="relative pt-32 pb-24 md:pt-40 md:pb-32 bg-white overflow-hidden" id="hero-entry">
        {/* Background Accent Gradients */}
        <div className="absolute top-0 right-0 h-[450px] w-[450px] bg-brand-orange/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-20 left-0 h-[300px] w-[300px] bg-brand-navy/5 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            
            {/* Hero Typography Column */}
            <div className="lg:col-span-5 text-left space-y-6" id="hero-typography">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-brand-orange-light text-brand-orange text-xs font-bold font-mono tracking-wider">
                <span className="h-1.5 w-1.5 rounded-full bg-brand-orange animate-pulse"></span>
                Now Available for Regional Dispatch
              </span>

              {/* Taglines requested - Run Jobs. Grow Business. Stay in Control. */}
              <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-black text-brand-navy leading-[1.08] tracking-tight">
                Run Jobs. <br />
                <span className="text-brand-orange">Grow Business.</span> <br />
                Stay in Control.
              </h1>

              {/* Subheadline copy matching strategy */}
              <p className="text-brand-slate text-base sm:text-lg leading-relaxed max-w-lg">
                True Pro helps outdoor service businesses manage scheduling, estimates, jobs, crews, invoices, and follow-up from one connected platform.
              </p>

              {/* Balanced, understated Buttons. No over-buttoning, no Watch Demo/Free Trials unless active. */}
              <div className="pt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                <button
                  onClick={() => openDemo('general')}
                  className="px-8 py-3.5 rounded-xl bg-brand-orange text-white text-sm font-bold shadow-md hover:bg-brand-orange-hover hover:scale-[1.01] transition-all cursor-pointer flex items-center justify-center gap-2"
                  id="hero-primary-cta"
                >
                  Book a Demo
                  <ArrowRight className="h-4 w-4" />
                </button>
                <button
                  onClick={() => scrollToSection('features')}
                  className="px-8 py-3.5 rounded-xl bg-white text-brand-navy border border-slate-200 text-sm font-bold shadow-sm hover:border-slate-350 hover:bg-slate-50 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  id="hero-secondary-cta"
                >
                  See How It Works
                </button>
              </div>

              {/* Built-in high trust endorsement under buttons */}
              <p className="text-[11px] text-slate-500 font-medium flex items-center gap-1 bg-slate-50 p-2.5 rounded-lg max-w-sm">
                <ShieldCheck className="h-4 w-4 text-brand-orange font-semibold shrink-0" />
                Empowering operators across Landscaping, Hardscaping, Pool/Spa & Pest.
              </p>
            </div>

            {/* High Fidelity Visual Dashboard Column */}
            <div className="lg:col-span-7" id="hero-dashboard-container">
              <InteractiveDashboard />
            </div>

          </div>
        </div>
      </section>

      {/* TRUST / PROOF STRIP */}
      <section className="bg-slate-50 py-10 border-y border-slate-100" id="trust-strip-container">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-xs font-mono font-bold uppercase tracking-widest text-slate-400 text-center mb-8">
            Coordinated Field Operations State
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {trustPoints.map((point, index) => (
              <div 
                key={index} 
                className="flex items-start gap-3 bg-white p-4 rounded-xl border border-slate-200/60 shadow-2xs hover:border-brand-navy/10 transition-colors"
                id={`trust-point-${index}`}
              >
                <div className="h-8 w-8 rounded-lg bg-orange-50 text-brand-orange flex items-center justify-center shrink-0">
                  <Check className="h-4.5 w-4.5 stroke-[2.5]" />
                </div>
                <div>
                  <h4 className="font-display font-medium text-xs sm:text-sm text-brand-navy tracking-tight">
                    {point.text}
                  </h4>
                  <p className="text-[11px] text-slate-400 font-mono tracking-tight mt-0.5">
                    {point.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* THREE STEP WORKFLOW */}
      <WorkflowSection onBookDemo={() => openDemo('general')} />

      {/* FEATURE GRID */}
      <FeatureGrid onBookDemo={() => openDemo('general')} />

      {/* SECTOR FOCUS: BUILT FOR OUTDOOR SERVICES */}
      <IndustriesSection onBookDemo={() => openDemo('general')} />

      {/* FINAL CALL TO ACTION */}
      <CTASection onBookDemo={() => openDemo('general')} />

      {/* FOOTER */}
      <footer className="bg-brand-navy-dark text-slate-400 py-16 border-t border-slate-800" id="truepro-site-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-10">
          
          {/* Logo Column */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-orange">
                <span className="font-display text-sm font-black text-white italic">TP</span>
              </div>
              <span className="font-display text-lg font-bold text-white tracking-tight">
                True<span className="text-brand-orange">Pro</span>
              </span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Software engineered explicitly for outdoor service professionals. Aligning estimates, scheduling, crews, invoicing, and follow-ups securely.
            </p>
          </div>

          {/* Solutions links */}
          <div className="space-y-3">
            <h5 className="font-display text-white text-xs font-bold uppercase tracking-wider">Solutions</h5>
            <ul className="text-xs space-y-2 text-slate-500">
              <li><button onClick={() => scrollToSection('features')} className="hover:text-white hover:underline cursor-pointer">Live Scheduling Tool</button></li>
              <li><button onClick={() => scrollToSection('features')} className="hover:text-white hover:underline cursor-pointer">Mobile Crew Dispatch</button></li>
              <li><button onClick={() => scrollToSection('features')} className="hover:text-white hover:underline cursor-pointer">Job Costing Safeguards</button></li>
              <li><button onClick={() => scrollToSection('features')} className="hover:text-white hover:underline cursor-pointer">Proposals & Client Portal</button></li>
            </ul>
          </div>

          {/* Industry links */}
          <div className="space-y-3">
            <h5 className="font-display text-white text-xs font-bold uppercase tracking-wider">Outdoor Verticals</h5>
            <ul className="text-xs space-y-2 text-slate-500">
              <li><button onClick={() => { scrollToSection('industries'); setSelectedIndustry('landscaping'); }} className="hover:text-white hover:underline">Landscaping & Rotations</button></li>
              <li><button onClick={() => { scrollToSection('industries'); setSelectedIndustry('hardscaping'); }} className="hover:text-white hover:underline">Hardscaping & Supply</button></li>
              <li><button onClick={() => { scrollToSection('industries'); setSelectedIndustry('pool-spa'); }} className="hover:text-white hover:underline">Pool & Spa Services</button></li>
              <li><button onClick={() => { scrollToSection('industries'); setSelectedIndustry('pest-control'); }} className="hover:text-white hover:underline">Pest & Compliance</button></li>
            </ul>
          </div>

          {/* Trust Statement */}
          <div className="space-y-3">
            <h5 className="font-display text-white text-xs font-bold uppercase tracking-wider">Operations Safety</h5>
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl text-xs space-y-2">
              <p className="text-slate-400 leading-relaxed font-mono text-[11px]">
                True Pro structures routing, database parameters, and live status variables dynamically according to strict field compliance guidelines.
              </p>
              <div className="flex items-center gap-1.5 text-[10px] text-brand-orange font-semibold">
                <ShieldCheck className="h-4 w-4" /> SECURE DATA ENVELOPE
              </div>
            </div>
          </div>

        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-4">
          <p>&copy; {new Date().getFullYear()} True Pro Software. All Rights Reserved.</p>
          <div className="flex gap-4">
            <span className="hover:text-white cursor-pointer">Service Terms</span>
            <span className="hover:text-white cursor-pointer">Privacy Guidelines</span>
            <span className="hover:text-white cursor-pointer">Operational SLA</span>
          </div>
        </div>
      </footer>

      {/* DEMO BOOKING MODAL OVERLAY */}
      <DemoModal 
        isOpen={isDemoOpen} 
        onClose={() => setIsDemoOpen(false)} 
        selectedIndustry={selectedIndustry}
      />

    </div>
  );
}

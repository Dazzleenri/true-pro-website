export interface FeatureItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  badge?: string;
  operationalValue: string;
}

export interface IndustryItem {
  id: string;
  name: string;
  description: string;
  iconName: string;
  keyChallenge: string;
  solution: string;
}

export interface WorkflowStep {
  stepNumber: string;
  title: string;
  description: string;
  details: string[];
}

export interface DemoSession {
  companyName: string;
  contactName: string;
  phone: string;
  email: string;
  industry: string;
  date: string;
  time: string;
}

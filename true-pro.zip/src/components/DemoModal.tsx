import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Calendar, Clock, Building2, User, Phone, Mail, Info, ArrowRight } from 'lucide-react';

interface DemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedIndustry?: string;
}

export default function DemoModal({ isOpen, onClose, selectedIndustry = 'general' }: DemoModalProps) {
  const [formData, setFormData] = useState({
    fullName: '',
    companyName: '',
    email: '',
    phone: '',
    industry: selectedIndustry === 'general' ? 'landscaping' : selectedIndustry,
    crewSize: '1-5',
    preferredDate: '',
    preferredTime: 'morning',
  });

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-brand-navy/60 backdrop-blur-xs"
            id="modal-backdrop"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative z-10 w-full max-w-lg overflow-hidden rounded-2xl bg-white shadow-2xl border border-brand-slate-light"
            id="demo-modal-container"
          >
            {/* Header */}
            <div className="flex items-center justify-between bg-brand-navy p-6 text-white">
              <div>
                <h3 className="font-display text-xl font-bold tracking-tight">Book an Operational Demo</h3>
                <p className="mt-1 text-xs text-slate-300">
                  See how True Pro aligns your specific office and field work.
                </p>
              </div>
              <button
                onClick={onClose}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
                id="close-modal-button"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Content & Form */}
            <div className="p-6 max-h-[80vh] overflow-y-auto w-full">
              <form action="https://formsubmit.co/brandon.conroy@truepro.com" method="POST" className="space-y-4" id="demo-booking-form">
                {/* FormSubmit configuration inputs */}
                <input type="hidden" name="_subject" value="New True Pro Demo Request" />
                <input type="hidden" name="_captcha" value="false" />
                <input type="hidden" name="_template" value="table" />
                <input type="text" name="_honey" style={{ display: 'none' }} />

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-brand-slate mb-1">
                      Full Name *
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <input
                        type="text"
                        required
                        name="fullName"
                        value={formData.fullName}
                        onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                        placeholder="John Carter"
                        className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-3 text-sm focus:border-brand-orange focus:ring-1 focus:ring-brand-orange focus:outline-none"
                        id="input-full-name"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-brand-slate mb-1">
                      Company Name *
                    </label>
                    <div className="relative">
                      <Building2 className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <input
                        type="text"
                        required
                        name="companyName"
                        value={formData.companyName}
                        onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                        placeholder="Apex Landscaping LLC"
                        className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-3 text-sm focus:border-brand-orange focus:ring-1 focus:ring-brand-orange focus:outline-none"
                        id="input-company-name"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-brand-slate mb-1">
                      Work Phone *
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <input
                        type="tel"
                        required
                        name="workPhone"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="(555) 019-2834"
                        className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-3 text-sm focus:border-brand-orange focus:ring-1 focus:ring-brand-orange focus:outline-none"
                        id="input-phone"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-brand-slate mb-1">
                      Work Email *
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <input
                        type="email"
                        required
                        name="workEmail"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="john@apexlandscaping.com"
                        className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-3 text-sm focus:border-brand-orange focus:ring-1 focus:ring-brand-orange focus:outline-none"
                        id="input-email"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-brand-slate mb-1">
                      Industry Sector
                    </label>
                    <select
                      name="industrySector"
                      value={formData.industry}
                      onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                      className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-brand-orange focus:ring-1 focus:ring-brand-orange focus:outline-none bg-white"
                      id="select-industry"
                    >
                      <option value="landscaping">Landscaping & Design</option>
                      <option value="hardscaping">Hardscaping & Masonry</option>
                      <option value="pool-spa">Pool & Spa Services</option>
                      <option value="pest-control">Pest Control Crews</option>
                      <option value="irrigation">Irrigation & Lighting</option>
                      <option value="general">General Field Operations</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-brand-slate mb-1">
                      Active Field Crews
                    </label>
                    <select
                      name="activeFieldCrews"
                      value={formData.crewSize}
                      onChange={(e) => setFormData({ ...formData, crewSize: e.target.value })}
                      className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-brand-orange focus:ring-1 focus:ring-brand-orange focus:outline-none bg-white"
                      id="select-crew-size"
                    >
                      <option value="1-5">1 - 5 Crews</option>
                      <option value="6-15">6 - 15 Crews</option>
                      <option value="16-30">16 - 30 Crews</option>
                      <option value="31+">31+ Mobile Crews</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 pt-2">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-brand-slate mb-1">
                      Preferred Date
                    </label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <input
                        type="date"
                        name="preferredDate"
                        value={formData.preferredDate}
                        onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                        className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-3 text-sm focus:border-brand-orange focus:ring-1 focus:ring-brand-orange focus:outline-none"
                        id="input-date"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-brand-slate mb-1">
                      Preferred Time of Day
                    </label>
                    <div className="relative">
                      <Clock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <select
                        name="preferredTime"
                        value={formData.preferredTime}
                        onChange={(e) => setFormData({ ...formData, preferredTime: e.target.value })}
                        className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-3 text-sm focus:border-brand-orange focus:ring-1 focus:ring-brand-orange focus:outline-none bg-white"
                        id="select-time"
                      >
                        <option value="morning">Morning (8am - 12pm)</option>
                        <option value="afternoon">Afternoon (12pm - 4pm)</option>
                        <option value="late">Late Session (4pm - 6pm)</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg bg-orange-50 p-4 border border-orange-100 flex gap-3 text-xs text-brand-slate">
                  <Info className="h-4 w-4 text-brand-orange shrink-0 mt-0.5" />
                  <p>
                    <strong>Live Demonstration Offer:</strong> Our product advisors will call and walk you through scheduling and crew dispatch templates configured for your industry, answer custom questions, and set up your customized account.
                  </p>
                </div>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-brand-orange py-3 text-sm font-semibold text-white shadow-md hover:bg-brand-orange-hover hover:scale-[1.01] transition-all"
                  id="submit-demo"
                >
                  Confirm Demopoint Selection
                  <ArrowRight className="h-4 w-4" />
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

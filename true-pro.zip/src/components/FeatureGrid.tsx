import { 
  Calendar, DollarSign, FileCheck, CreditCard, Smartphone, 
  UserCheck, BarChart3, Globe, UsersRound, HelpCircle 
} from 'lucide-react';
import { FeatureItem } from '../types';

interface FeatureGridProps {
  onBookDemo: () => void;
}

export default function FeatureGrid({ onBookDemo }: FeatureGridProps) {
  
  const features: FeatureItem[] = [
    {
      id: "feat-sch",
      title: "Smart Scheduling",
      description: "Dispatch crews on map-optimized routes in a visual calendar. Change jobs on the fly and auto-notify crew members in the field.",
      iconName: "Calendar",
      operationalValue: "Eliminate double-booking and reduce wind-shield travel time."
    },
    {
      id: "feat-cost",
      title: "Job Costing",
      description: "Track materials used, actual hours logged, and contractor fees directly against your proposed budget to protect your profits.",
      iconName: "DollarSign",
      badge: "Profit Saver",
      operationalValue: "Verify exact margin targets on every completed project live."
    },
    {
      id: "feat-est",
      title: "Estimates & Proposals",
      description: "Generate professional estimates formatted for mobile viewing. Field crews can adjust scopes and secure client reviews immediately.",
      iconName: "FileCheck",
      operationalValue: "Save office time by having proposals approved on-site."
    },
    {
      id: "feat-inv",
      title: "Invoicing",
      description: "Automatically convert finished jobs into digital invoices with clickable credit card options, and direct processing options.",
      iconName: "CreditCard",
      operationalValue: "Reduce outstanding account balances from 30 days to instant."
    },
    {
      id: "feat-crew",
      title: "Mobile Crew App",
      description: "A fast, simple interface for field workers. Crews can view routing directions, check off safety lists, and upload completion photos.",
      iconName: "Smartphone",
      badge: "Built for Field Use",
      operationalValue: "Gives crew leads exactly what they need, even offline."
    },
    {
      id: "feat-portal",
      title: "Client Portal",
      description: "A secure online dashboard where customers can check upcoming maintenance dates, view historical proposals, and pay bills.",
      iconName: "UserCheck",
      operationalValue: "Reduces basic inquiries to the office by up to 40%."
    },
    {
      id: "feat-rep",
      title: "Reporting & Analytics",
      description: "Identify which services and regions deliver the highest profits. Review individual crew speeds, inventory turn, and invoice speeds.",
      iconName: "BarChart3",
      operationalValue: "Replace gut feeling with accurate business operational data."
    },
    {
      id: "feat-multi",
      title: "Multi-Location Operations",
      description: "Coordinate separate satellite yards, equipment centers, or branches. Perfect for growing teams scaling across regional zones.",
      iconName: "Globe",
      operationalValue: "Centralize back-office overhead while empowering local depots."
    },
    {
      id: "feat-crm",
      title: "CRM & Follow-Ups",
      description: "Secure seasonal renewals with automated, pre-configured email follow-ups. Build high-quality client histories and route reviews.",
      iconName: "UsersRound",
      operationalValue: "Capture renewal pipelines and repeat contracts effortlessly."
    }
  ];

  // Helper to map string dynamic icons matching types exactly
  const selectIcon = (iconName: string) => {
    switch (iconName) {
      case "Calendar": return <Calendar className="h-6 w-6" />;
      case "DollarSign": return <DollarSign className="h-6 w-6" />;
      case "FileCheck": return <FileCheck className="h-6 w-6" />;
      case "CreditCard": return <CreditCard className="h-6 w-6" />;
      case "Smartphone": return <Smartphone className="h-6 w-6" />;
      case "UserCheck": return <UserCheck className="h-6 w-6" />;
      case "BarChart3": return <BarChart3 className="h-6 w-6" />;
      case "Globe": return <Globe className="h-6 w-6" />;
      case "UsersRound": return <UsersRound className="h-6 w-6" />;
      default: return <HelpCircle className="h-6 w-6" />;
    }
  };

  return (
    <section className="py-20 bg-slate-50 border-y border-slate-100" id="features">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="text-xs font-mono font-bold tracking-wider text-brand-orange uppercase bg-orange-50 px-3 py-1.5 rounded-full border border-orange-100">
            Modular Platform Capabilities
          </span>
          <h2 className="mt-4 font-display text-3xl sm:text-4xl font-extrabold tracking-tight text-brand-navy">
            Everything Your Outdoor Service Business Needs to Run Cleaner
          </h2>
          <p className="mt-4 text-base sm:text-lg text-brand-slate leading-relaxed">
            Bring scheduling, estimates, job tracking, crews, invoices, and customer follow-up into one connected workflow.
          </p>
        </div>

        {/* Features Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feat) => (
            <div 
              key={feat.id}
              className="group relative flex flex-col justify-between rounded-2xl bg-white border border-slate-200 p-6 shadow-xs hover:shadow-md hover:border-brand-navy/20 transition-all duration-300"
              id={`feature-card-${feat.id}`}
            >
              <div>
                {/* Header line */}
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 bg-brand-orange-light text-brand-orange rounded-xl group-hover:bg-brand-orange group-hover:text-white transition-colors duration-300">
                    <div>
                      {selectIcon(feat.iconName)}
                    </div>
                  </div>
                  {feat.badge && (
                    <span className="text-[10px] uppercase tracking-wider font-mono font-bold bg-brand-navy text-white px-2 py-1 rounded">
                      {feat.badge}
                    </span>
                  )}
                </div>

                {/* Info */}
                <h3 className="font-display text-lg font-bold text-brand-navy group-hover:text-brand-orange transition-colors">
                  {feat.title}
                </h3>
                <p className="mt-2 text-sm text-brand-slate leading-relaxed">
                  {feat.description}
                </p>
              </div>

              {/* Operational Value highlight */}
              <div className="mt-5 pt-4 border-t border-slate-100">
                <p className="text-xs italic text-brand-navy font-semibold flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-brand-orange rounded-full inline-block"></span>
                  Value: {feat.operationalValue}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Feature Bottom Trust Area */}
        <div className="mt-16 text-center">
          <p className="text-xs text-brand-slate max-w-lg mx-auto leading-relaxed">
            Stop stitching together generic messaging apps, paper notebooks, and complicated office spreadsheets. Bring clarity to your team with True Pro's connected field suite.
          </p>
          <button 
            onClick={onBookDemo}
            className="mt-4 text-xs font-bold text-brand-orange hover:text-brand-orange-hover inline-flex items-center gap-1 group cursor-pointer"
            id="features-bottom-cta"
          >
            See exactly how these features work together
            <span className="group-hover:translate-x-1 transition-transform">&rarr;</span>
          </button>
        </div>

      </div>
    </section>
  );
}

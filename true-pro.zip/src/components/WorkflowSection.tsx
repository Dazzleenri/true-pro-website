import { 
  FileSignature, Calendar, CheckSquare, ShieldQuestion, 
  Sparkles, CreditCard, ChevronRight, BarChart 
} from 'lucide-react';

interface WorkflowSectionProps {
  onBookDemo: () => void;
}

export default function WorkflowSection({ onBookDemo }: WorkflowSectionProps) {
  
  const steps = [
    {
      num: "01",
      title: "Plan the Work",
      description: "Build beautiful, mobile-friendly proposals, verify margins against costs, and map scheduling variables in a connected master calendar.",
      elements: [
        "Create custom templates for materials and labor costs",
        "Avoid crew schedule overlaps directly from a map view",
        "Send automatic pre-visit confirmations to clients"
      ],
      icon: <FileSignature className="h-5 w-5 text-brand-orange" />
    },
    {
      num: "02",
      title: "Run the Jobs",
      description: "Dispatch optimized routes to your field crews' mobile apps, coordinate work steps, capture photo proof of service, and log offline progress metrics.",
      elements: [
        "Provide mobile directions to trucks to cut down delays",
        "Document site inspections and chemical volume metrics",
        "Submit completed work reports to the office in one click"
      ],
      icon: <CheckSquare className="h-5 w-5 text-brand-orange" />
    },
    {
      num: "03",
      title: "Track the Business",
      description: "Convert completed field logs into custom digital invoices, process fast, secure client payments, and monitor actual performance over time.",
      elements: [
        "Send automatic digital invoices right upon check-out",
        "Receive visual bank deposits in your preferred bank account",
        "Analyze monthly revenue outputs, product margin tracking, and active crew speeds"
      ],
      icon: <BarChart className="h-5 w-5 text-brand-orange" />
    }
  ];

  return (
    <section className="py-20 bg-slate-50 border-t border-slate-200" id="how-it-helps">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header segment */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="text-xs font-mono font-bold tracking-wider text-brand-orange uppercase bg-orange-50 px-3 py-1.5 rounded-full border border-orange-100">
            Systematic Confidence Flow
          </span>
          <h2 className="mt-4 font-display text-3xl sm:text-4xl font-extrabold tracking-tight text-brand-navy">
            How True Pro Helps Your Team Succeed
          </h2>
          <p className="mt-4 text-base sm:text-lg text-brand-slate leading-relaxed">
            Stop guessing if jobs are profitable or if crews are on track. True Pro brings office coordinators, administrators, and field leads into one real-time cycle.
          </p>
        </div>

        {/* Vertical list of process blocks */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {steps.map((st, idx) => (
            <div 
              key={st.num}
              className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col justify-between shadow-xs hover:shadow-md hover:border-brand-navy/10 transition-all duration-300 relative group"
              id={`workflow-step-${st.num}`}
            >
              <div>
                {/* Step indicator info */}
                <div className="flex justify-between items-center mb-6">
                  <div className="h-10 w-10 rounded-xl bg-orange-50 border border-orange-100 flex items-center justify-center font-bold">
                    {st.icon}
                  </div>
                  <span className="font-mono text-3xl font-black text-slate-200 group-hover:text-brand-orange/30 transition-colors leading-none select-none">
                    {st.num}
                  </span>
                </div>

                <h3 className="font-display text-lg sm:text-xl font-bold text-brand-navy mb-3">
                  {st.title}
                </h3>
                <p className="text-sm text-brand-slate leading-relaxed mb-6">
                  {st.description}
                </p>

                {/* Checklist elements */}
                <div className="space-y-2 pb-6 border-b border-slate-100">
                  {st.elements.map((el, itemIdx) => (
                    <div key={itemIdx} className="flex gap-2 text-xs text-brand-slate leading-normal">
                      <span className="inline-block h-1.5 w-1.5 bg-brand-orange rounded-full shrink-0 mt-1.5"></span>
                      <span>{el}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Box footer */}
              <div className="pt-4 flex items-center justify-between text-xs font-bold text-brand-navy">
                <span className="text-slate-400 font-mono text-[10px]">Pillar {1 + idx} of 3</span>
                <span className="text-brand-orange group-hover:translate-x-1.5 transition-transform flex items-center gap-1 cursor-pointer" onClick={onBookDemo}>
                  Learn more <ChevronRight className="h-3.5 w-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Multi-role engagement sub-section */}
        <div className="mt-16 bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-slate-200 shadow-xs">
          
          <div className="pb-6 md:pb-0 md:pr-6 space-y-2">
            <span className="text-[10px] font-mono font-bold text-brand-orange uppercase">Created for</span>
            <h4 className="font-display text-base font-bold text-brand-navy">Field Crews</h4>
            <p className="text-xs text-brand-slate leading-relaxed">
              Provides beautiful mobile dispatch routings, clear tasks lists, offline-capable note logs, and snap-to-save photo portals. No complex inputs required.
            </p>
          </div>

          <div className="py-6 md:py-0 md:px-6 space-y-2">
            <span className="text-[10px] font-mono font-bold text-brand-orange uppercase font-semibold">Centered on</span>
            <h4 className="font-display text-base font-bold text-brand-navy">Office Teams</h4>
            <p className="text-xs text-brand-slate leading-relaxed">
              Consolidate client directories, map routes dynamically, update invoicing timelines, and monitor multi-region active truck queues in real-time.
            </p>
          </div>

          <div className="pt-6 md:pt-0 md:pl-6 space-y-2">
            <span className="text-[10px] font-mono font-bold text-brand-orange uppercase font-semibold">Protecting</span>
            <h4 className="font-display text-base font-bold text-brand-navy">Business Owners</h4>
            <p className="text-xs text-brand-slate leading-relaxed">
              Track labor leakage rates, target live material margins, increase contract renewal speeds, and maintain deep strategic control of your growth.
            </p>
          </div>

        </div>

      </div>
    </section>
  );
}

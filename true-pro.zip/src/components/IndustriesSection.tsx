import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trees, Hammer, Droplets, ShieldAlert, Sliders, Check, Dot, Info 
} from 'lucide-react';
import { IndustryItem } from '../types';

interface IndustriesSectionProps {
  onBookDemo: () => void;
}

export default function IndustriesSection({ onBookDemo }: IndustriesSectionProps) {
  
  const industries: IndustryItem[] = [
    {
      id: "landscaping",
      name: "Landscaping",
      description: "Manage maintenance rotations, crew routing maps, and seasonal landscape design quotes seamlessly.",
      iconName: "Trees",
      keyChallenge: "Handling recurring residential mower schedules alongside high-margin custom patio designs on the same calendar.",
      solution: "Split view scheduling permits recurring crews to be optimized on local postal routes, while design teams get granular materials tracking."
    },
    {
      id: "hardscaping",
      name: "Hardscaping & Masonry",
      description: "Calculate accurate gravel, stone, soil yardage weight margins, and keep tabs on expensive heavy equipment locations.",
      iconName: "Hammer",
      keyChallenge: "Failing to account for escalating material pricing and machine delivery rental delays on multi-week projects.",
      solution: "Detailed progressive job costing tracks purchase orders and machine run-hours against milestones, highlighting variances on the fly."
    },
    {
      id: "pool-spa",
      name: "Pool & Spa",
      description: "Log chemical diagnostics, equipment part numbers, water temperature metrics, and seasonal winterization logs.",
      iconName: "Droplets",
      keyChallenge: "Disgruntled residential homeowners complaining that technicians skipped maintenance visits or missed filter safety checks.",
      solution: "Automatic digital check-in logs with timestamped chemical reports and pool maintenance photo reports are pushed directly into the client portal."
    },
    {
      id: "pest-control",
      name: "Pest Control",
      description: "Organize address-specific treatment cycles, license validations, chemical spray recordings, and compliance histories.",
      iconName: "ShieldAlert",
      keyChallenge: "Keeping compliant with local regulations while managing separate chemical inventory allocations across five individual utility vans.",
      solution: "A mobile tracking log requires crew leads to specify active compound metrics and volume formulas before starting any residential service checklist."
    },
    {
      id: "irrigation",
      name: "Irrigation & Lighting",
      description: "Map sprinkler zones, catalog low-voltage controller lines, carry out winter pipe blowing, and catalog system designs.",
      iconName: "Sliders",
      keyChallenge: "Emergency pipe bursts and broken low-voltage wiring requests messing up the pre-arranged weekly work route for field service tech teams.",
      solution: "An interactive dispatch list enables office managers to drop an emergency site visit right onto the nearest available truck's visual mobile route."
    }
  ];

  const [activeIndustry, setActiveIndustry] = useState<string>(industries[0].id);

  const selectedData = industries.find(ind => ind.id === activeIndustry) || industries[0];

  const getIcon = (name: string, active: boolean) => {
    const cls = `h-6 w-6 transition-all ${active ? 'text-white' : 'text-brand-orange'}`;
    switch (name) {
      case "Trees": return <Trees className={cls} />;
      case "Hammer": return <Hammer className={cls} />;
      case "Droplets": return <Droplets className={cls} />;
      case "ShieldAlert": return <ShieldAlert className={cls} />;
      default: return <Sliders className={cls} />;
    }
  };

  return (
    <section className="py-20 bg-white" id="industries">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Segment */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="text-xs font-mono font-bold tracking-wider text-brand-orange uppercase bg-orange-50 px-3 py-1.5 rounded-full border border-orange-100">
            Tailored Sector Operations
          </span>
          <h2 className="mt-4 font-display text-3xl sm:text-4xl font-extrabold tracking-tight text-brand-navy">
            Built Specifically for Outdoor Service Pros
          </h2>
          <p className="mt-4 text-base sm:text-lg text-brand-slate leading-relaxed">
            True Pro adapts to your exact day-to-day requirements. Tap your sector below to see how our layout, dispatch features, and mobile crew checklist structure update.
          </p>
        </div>

        {/* Tab Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Active List */}
          <div className="col-span-1 lg:col-span-5 space-y-3">
            {industries.map((ind) => {
              const isActive = ind.id === activeIndustry;
              return (
                <button
                  key={ind.id}
                  onClick={() => setActiveIndustry(ind.id)}
                  className={`w-full text-left p-4 rounded-2xl border transition-all flex items-center gap-4 cursor-pointer ${
                    isActive 
                      ? 'bg-brand-navy border-brand-navy text-white shadow-md' 
                      : 'bg-slate-50 border-slate-200 text-brand-navy hover:bg-slate-100/70'
                  }`}
                  id={`industry-tab-${ind.id}`}
                >
                  <div className={`p-2.5 rounded-xl transition-colors ${isActive ? 'bg-brand-orange text-white' : 'bg-white text-brand-orange border border-slate-200'}`}>
                    {getIcon(ind.iconName, isActive)}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-display font-bold text-sm sm:text-base">{ind.name}</h4>
                    <p className={`text-xs mt-0.5 max-w-xs truncate ${isActive ? 'text-slate-300' : 'text-brand-slate'}`}>
                      {ind.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Interactive Showcase Box */}
          <div className="col-span-1 lg:col-span-7" id="industry-showcase-container">
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedData.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.25 }}
                className="rounded-3xl bg-slate-50 border border-slate-200 p-6 sm:p-8 space-y-6 shadow-xs relative overflow-hidden"
              >
                {/* Visual accent */}
                <div className="absolute right-0 top-0 h-24 w-24 bg-orange-100/30 rounded-full blur-2xl pointer-events-none"></div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
                  <div>
                    <span className="text-[10px] font-mono font-bold tracking-wider uppercase text-brand-orange">
                      Industry Focused Blueprint
                    </span>
                    <h3 className="font-display text-xl sm:text-2xl font-black text-brand-navy mt-1">
                      True Pro for {selectedData.name}
                    </h3>
                  </div>
                  <div className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-xs font-mono text-slate-500">
                    Template: Active_{selectedData.id}.json
                  </div>
                </div>

                {/* The Obstacle / Key Challenge */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-brand-navy flex items-center gap-1.5">
                    <span className="inline-block w-2 h-2 rounded-full bg-brand-slate"></span>
                    Standard Field Chaos Point
                  </h4>
                  <p className="text-sm text-brand-slate leading-relaxed italic bg-white p-3.5 rounded-xl border border-slate-200">
                    "{selectedData.keyChallenge}"
                  </p>
                </div>

                {/* How True Pro Solves It */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-brand-orange flex items-center gap-1.5">
                    <span className="inline-block w-2 h-2 rounded-full bg-brand-orange"></span>
                    True Pro Solution State
                  </h4>
                  <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs space-y-3">
                    <p className="text-sm font-semibold text-brand-navy">
                      {selectedData.solution}
                    </p>
                    <ul className="text-xs text-brand-slate space-y-2 pt-2 border-t border-slate-100">
                      <li className="flex items-start gap-2">
                        <Check className="h-4 w-4 text-brand-orange shrink-0 mt-0.5" />
                        <span>Visualizes scheduling variables instantly to improve team capacity.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-4 w-4 text-brand-orange shrink-0 mt-0.5" />
                        <span>Ensures standard communication logs are logged automatically.</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <span className="text-xs text-brand-slate flex items-center gap-1">
                    <Info className="h-4 w-4 text-slate-400" /> Learn more about custom {selectedData.name} workflows.
                  </span>
                  <button
                    onClick={onBookDemo}
                    className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-brand-navy hover:bg-brand-orange text-xs font-bold text-white transition-all shadow-sm flex items-center justify-center gap-1"
                    id="industry-book-demo-cta"
                  >
                    Configure My {selectedData.name} Demo
                  </button>
                </div>

              </motion.div>
            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
}

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, DollarSign, MessageSquare, Check, ChevronRight, 
  Trash2, Building2, MapPin, User, FileText, 
  CheckCircle2, RefreshCw, FileSpreadsheet, Lock
} from 'lucide-react';

interface BidRecord {
  id: string;
  bidNumber: string;
  customer: string;
  property: string;
  amount: string;
  status: 'Approved' | 'Pending Payment' | 'Paid';
  crewLead: string;
}

interface NoteRecord {
  id: string;
  timeStamp: string;
  author: string;
  text: string;
}

export default function InteractiveDashboard() {
  // Setup reactive mock state to make the simulation fully alive!
  const [bids, setBids] = useState<BidRecord[]>([
    {
      id: "bid-1",
      bidNumber: "#BID-5801",
      customer: "Stone Creek HOA",
      property: "1200 East Sector Rd, Orlando",
      amount: "$12,400",
      status: "Approved",
      crewLead: "Mike Henderson"
    },
    {
      id: "bid-2",
      bidNumber: "#BID-5102",
      customer: "Westgate Resorts",
      property: "884 Altamonte Ave, Orlando",
      amount: "$3,350",
      status: "Pending Payment",
      crewLead: "Dave Brody"
    },
    {
      id: "bid-3",
      bidNumber: "#BID-5303",
      customer: "Marianne Jenkins",
      property: "52 Lakeside Dr, Orlando",
      amount: "$1,850",
      status: "Paid",
      crewLead: "Sal Mercado"
    }
  ]);

  const [notes, setNotes] = useState<NoteRecord[]>([
    {
      id: "note-1",
      timeStamp: "09:14 AM",
      author: "Admins Office",
      text: "Crew Alpha dispatched to Stone Creek HOA for stone walkway check-in."
    }
  ]);

  const [newNoteText, setNewNoteText] = useState("");
  const [notification, setNotification] = useState<string | null>(null);

  // Helper trigger to log temporary user actions
  const showFlash = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  // Actions representing required button systems
  const handleCreateProposal = () => {
    const nextNum = 5800 + bids.length + 1;
    const newBid: BidRecord = {
      id: `bid-${Date.now()}`,
      bidNumber: `#BID-${nextNum}`,
      customer: "Green Valley Estates",
      property: "120 Orchard Rd, Orlando",
      amount: "$4,850",
      status: "Pending Payment",
      crewLead: "Mike Henderson"
    };
    setBids([newBid, ...bids]);
    showFlash(`Created Proposal ${newBid.bidNumber} for Green Valley Estates successfully!`);
  };

  const handleCreateGeneric = () => {
    const nextNum = 5600 + bids.length + 1;
    const newBid: BidRecord = {
      id: `bid-${Date.now()}`,
      bidNumber: `#BID-${nextNum}`,
      customer: "Apex Commercial Plaza",
      property: "772 Downtown Plaza, Orlando",
      amount: "$6,200",
      status: "Approved",
      crewLead: "Dave Brody"
    };
    setBids([newBid, ...bids]);
    showFlash(`Generic estimate record ${newBid.bidNumber} generated successfully!`);
  };

  const handleReceiveMoney = () => {
    // Find first pending payment proposal and mark as paid
    const pendingIdx = bids.findIndex(b => b.status === 'Pending Payment');
    if (pendingIdx !== -1) {
      const updated = [...bids];
      const target = updated[pendingIdx];
      target.status = 'Paid';
      setBids(updated);
      showFlash(`Received payment for Bid ${target.bidNumber} — Ledger status updated to PAID!`);
    } else {
      showFlash("All estimates are already processed. Click Create or Create Proposal first.");
    }
  };

  const handleAddNote = () => {
    if (!newNoteText.trim()) {
      showFlash("Please type a note message first.");
      return;
    }
    const chunk: NoteRecord = {
      id: `note-${Date.now()}`,
      timeStamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      author: "Coordinators Desk",
      text: newNoteText
    };
    setNotes([chunk, ...notes]);
    setNewNoteText("");
    showFlash("System status note appended directly to active timeline feed.");
  };

  const handleClearLedger = () => {
    setBids([
      {
        id: "bid-1",
        bidNumber: "#BID-5801",
        customer: "Stone Creek HOA",
        property: "1200 East Sector Rd, Orlando",
        amount: "$12,400",
        status: "Approved",
        crewLead: "Mike Henderson"
      },
      {
        id: "bid-2",
        bidNumber: "#BID-5102",
        customer: "Westgate Resorts",
        property: "884 Altamonte Ave, Orlando",
        amount: "$3,350",
        status: "Pending Payment",
        crewLead: "Dave Brody"
      }
    ]);
    setNotes([
      {
        id: "note-1",
        timeStamp: "09:14 AM",
        author: "Admins Office",
        text: "Crew Alpha dispatched to Stone Creek HOA for stone walkway check-in."
      }
    ]);
    showFlash("Ledger state reset back to default True Pro database parameters.");
  };

  return (
    <div 
      className="w-full rounded-2xl bg-brand-navy border border-brand-navy-light/40 shadow-2xl overflow-hidden text-slate-800" 
      id="true-pro-dashboard-workspace"
    >
      {/* 1. MOCK OPERATIONAL APP HEADER (Deep Navy background #0F172A | Left aligned TP Logo | White Nav Text) */}
      <div className="bg-brand-navy px-5 py-4 border-b border-brand-navy-light/40 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {/* Approved TP Logo Element */}
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-orange text-white italic font-black shrink-0">
            TP
          </div>
          <div className="h-4 w-px bg-slate-700"></div>
          <div>
            <span className="text-sm font-bold text-white tracking-tight">True Pro Control Desk</span>
            <span className="hidden sm:inline-block text-[10px] font-mono font-medium text-brand-orange bg-brand-navy-light px-2 py-0.5 rounded ml-2.5">
              Live Connection
            </span>
          </div>
        </div>

        {/* Navigation Elements - Pure Crisp White Text on Deep Navy Background */}
        <div className="flex items-center gap-4 text-xs font-semibold text-white">
          <span className="hover:text-brand-orange transition-colors cursor-pointer border-b-2 border-brand-orange pb-0.5">Estimates</span>
          <span className="hover:text-brand-orange opacity-80 sm:block hidden transition-colors cursor-pointer">Dispatch</span>
          <span className="hover:text-brand-orange opacity-80 sm:block hidden transition-colors cursor-pointer">Invoicing</span>
          <span className="hover:text-brand-orange opacity-80 transition-colors cursor-pointer">Crews Map</span>
        </div>
      </div>

      {/* 2. BODY FRAME: SIDEBAR & MAIN LIGHT CONTENT SPACE COMBINED */}
      <div className="flex flex-col md:flex-row min-h-[460px] bg-slate-100">
        
        {/* SIDEBAR VIEW: MOCK SIDEBAR (Deep Navy Background #0F172A | Pure Crisp White Labels) */}
        <aside className="w-full md:w-48 bg-brand-navy border-r border-brand-navy-light/30 flex flex-col justify-between shrink-0">
          <div className="p-4 space-y-1">
            <span className="text-[9px] font-mono font-semibold text-brand-slate uppercase tracking-wider block mb-3 px-2">Core Directory</span>
            
            <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-brand-navy-light text-white text-xs font-semibold">
              <FileSpreadsheet className="h-3.5 w-3.5 text-brand-orange" />
              <span>Job Ledger</span>
            </div>
            
            <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-brand-navy-light/40 text-xs transition-colors cursor-pointer">
              <Building2 className="h-3.5 w-3.5 text-brand-slate" />
              <span>Customer Accounts</span>
            </div>

            <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-brand-navy-light/40 text-xs transition-colors cursor-pointer">
              <MapPin className="h-3.5 w-3.5 text-brand-slate" />
              <span>GPS Fleet Locations</span>
            </div>
            
            <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-brand-navy-light/40 text-xs transition-colors cursor-pointer">
              <User className="h-3.5 w-3.5 text-brand-slate" />
              <span>Crew Assignments</span>
            </div>
          </div>

          {/* Connected state badge */}
          <div className="p-4 border-t border-brand-navy-light/20 bg-brand-navy-dark/50 text-[10px] space-y-1.5 font-mono text-slate-400">
            <div className="flex items-center gap-1.5 text-white font-medium">
              <span className="w-2 h-2 rounded-full bg-brand-orange animate-pulse"></span>
              <span>Sync Endpoint Alive</span>
            </div>
            <p className="leading-tight text-[9px] text-slate-500">Node DB Connection Secure & Active</p>
          </div>
        </aside>

        {/* MAIN WORKSPACE AREA: LIGHT AND HIGH CONTRAST (Light Background #F8FAFC) */}
        <main className="flex-1 p-5 sm:p-6 bg-brand-slate-light flex flex-col justify-between gap-6" id="dashboard-light-workspace">
          
          <div className="space-y-5">
            {/* Action Toolbar Header with exact True Pro color requirements */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200">
              <div>
                <h3 className="text-base font-bold text-brand-navy font-display flex items-center gap-2">
                  <FileText className="h-4.5 w-4.5 text-brand-orange" />
                  Estimates, Proposals, and General Ledger
                </h3>
                <p className="text-xs text-brand-slate mt-0.5">Control pipeline states, trigger invoices, and note field status flags.</p>
              </div>

              {/* Status Indicator */}
              <div className="text-xs text-brand-navy font-mono bg-white px-3 py-1.5 rounded-lg border border-slate-200 flex items-center gap-2 shadow-2xs shrink-0 self-start sm:self-center">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-orange opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-orange"></span>
                </span>
                <span>88% Autopay Adoption</span>
              </div>
            </div>

            {/* Flash Info Bar */}
            <AnimatePresence mode="wait">
              {notification && (
                <motion.div 
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  className="bg-brand-navy text-white text-xs px-4 py-2.5 rounded-xl border border-brand-navy-light/50 flex items-center gap-2 "
                  id="dashboard-notification-bar"
                >
                  <CheckCircle2 className="h-4 w-4 text-brand-orange shrink-0" />
                  <span className="font-medium font-mono">{notification}</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* 3. BUTTON SYSTEM (Correct Brand Alignment) 
                - Primary buttons: Deep Navy #0F172A | White text | Rounded
                - Accent button: Orange #F5A623 | White text
                - Secondary buttons: White bg | Navy text | Light border
            */}
            <div className="flex flex-wrap items-center gap-2.5 p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] font-mono uppercase tracking-wider text-brand-slate font-bold pr-2 border-r border-slate-100 mr-1 block">
                Actions
              </span>

              {/* Primary Navy Buttons (#0F172A) */}
              <button 
                onClick={handleCreateProposal}
                className="px-3.5 py-2 rounded-lg bg-brand-navy hover:bg-brand-navy-dark text-white text-xs font-bold font-sans shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
                title="Create a gorgeous new field proposal"
              >
                <Plus className="h-3.5 w-3.5 text-brand-orange" />
                <span>Create Proposal</span>
              </button>

              <button 
                onClick={handleCreateGeneric}
                className="px-3.5 py-2 rounded-lg bg-brand-navy hover:bg-brand-navy-dark text-white text-xs font-bold font-sans shadow-xs transition-all cursor-pointer"
              >
                Create
              </button>

              {/* Blue #00A0DC button was replaced with Deep Navy #0F172A with white text */}
              <button 
                onClick={handleReceiveMoney}
                className="px-3.5 py-2 rounded-lg bg-brand-navy hover:bg-brand-navy-hover text-white text-xs font-bold font-sans shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
                title="Settle pending statements into paid logs"
              >
                <DollarSign className="h-3.5 w-3.5 text-brand-orange" />
                <span>Receive Money</span>
              </button>

              {/* Green #4ADE80 button was replaced with Primary Orange #F5A623 with white text */}
              <div className="flex-1 sm:max-w-xs flex gap-1.5 items-center sm:ml-auto w-full min-w-[200px]">
                <input 
                  type="text" 
                  value={newNoteText}
                  onChange={(e) => setNewNoteText(e.target.value)}
                  placeholder="Type dispatch note..."
                  className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-brand-navy-dark placeholder-slate-400 focus:outline-none focus:border-brand-orange flex-1 focus:bg-white"
                  onKeyDown={(e) => e.key === 'Enter' && handleAddNote()}
                />
                <button 
                  onClick={handleAddNote}
                  className="px-3 py-2 rounded-lg bg-brand-orange hover:bg-brand-orange-hover text-white text-xs font-bold shadow-xs transition-all shrink-0 cursor-pointer flex items-center gap-1"
                >
                  <MessageSquare className="h-3.5 w-3.5" />
                  <span>Add Note</span>
                </button>
              </div>

              {/* Secondary Buttons: White background | Navy text #0F172A | Light border */}
              <button 
                onClick={handleClearLedger}
                className="px-3 py-2 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 text-brand-navy text-xs font-bold transition-all cursor-pointer flex items-center gap-1 shrink-0"
              >
                <RefreshCw className="h-3.5 w-3.5 text-brand-slate" />
                <span>Clear Ledger</span>
              </button>
            </div>

            {/* 4. TABLE SECTION: Light table headers, white backgrounds */}
            <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-2xs">
              <table className="w-full text-left border-collapse">
                <thead>
                  {/* Keep: light gray table headers (#F1F5F9) */}
                  <tr className="bg-slate-50 border-b border-slate-100 text-[11px] uppercase tracking-wider text-brand-slate font-bold">
                    <th className="p-3.5">Bid# (Link)</th>
                    <th className="p-3.5">Customer (Link)</th>
                    <th className="p-3.5">Property (Link)</th>
                    <th className="p-3.5 text-right">Job Total</th>
                    <th className="p-3.5">Leader</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Edit</th>
                  </tr>
                </thead>
                <tbody className="text-xs divide-y divide-slate-100 text-brand-navy-dark">
                  {bids.map((bid) => (
                    <tr key={bid.id} className="hover:bg-slate-50/70 transition-colors">
                      {/* Interactive text Links custom-styled in Approved Primary Orange (#F5A623), replacing teal */}
                      <td className="p-3.5 font-mono">
                        <span 
                          onClick={() => showFlash(`Inspecting details for workflow sheet ${bid.bidNumber}`)}
                          className="text-brand-orange font-semibold hover:underline cursor-pointer"
                        >
                          {bid.bidNumber}
                        </span>
                      </td>
                      <td className="p-3.5 font-medium">
                        <span 
                          onClick={() => showFlash(`Opening corporate portal for customer: ${bid.customer}`)}
                          className="text-brand-orange hover:underline cursor-pointer flex items-center gap-1"
                        >
                          {bid.customer}
                        </span>
                      </td>
                      <td className="p-3.5 text-slate-600">
                        <span 
                          onClick={() => showFlash(`Mapping client property at: ${bid.property}`)}
                          className="text-brand-orange hover:underline cursor-pointer"
                        >
                          {bid.property}
                        </span>
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-brand-navy">{bid.amount}</td>
                      <td className="p-3.5 text-slate-500">{bid.crewLead}</td>
                      <td className="p-3.5">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                          bid.status === 'Paid' 
                            ? 'bg-brand-orange-light text-brand-orange border-brand-orange/20' 
                            : bid.status === 'Approved'
                            ? 'bg-brand-navy-light/10 text-brand-navy-light border-brand-navy-light/20'
                            : 'bg-yellow-50 text-yellow-700 border-yellow-200'
                        }`}>
                          {bid.status}
                        </span>
                      </td>
                      {/* Edit icons custom-styled in Primary Orange (#F5A623), replacing teal */}
                      <td className="p-3.5 text-right">
                        <button 
                          onClick={() => showFlash(`Triggered editing panel workflow for bid entry: ${bid.bidNumber}`)}
                          className="text-brand-orange hover:text-brand-orange-hover p-1 rounded hover:bg-slate-100 transition-colors cursor-pointer"
                        >
                          <ChevronRight className="h-4.5 w-4.5 inline" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Note logs layout using orange brand accents */}
            {notes.length > 0 && (
              <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3 shadow-2xs">
                <h4 className="text-xs font-bold uppercase tracking-wider text-brand-navy flex items-center gap-1.5 border-b border-slate-100 pb-2">
                  <span className="inline-block w-2 h-2 rounded-full bg-brand-orange"></span>
                  Active Dispatch Timeline Messages
                </h4>
                <div className="space-y-2 max-h-24 overflow-y-auto">
                  {notes.map((note) => (
                    <div key={note.id} className="text-xs flex items-start gap-2 leading-relaxed">
                      <span className="font-mono text-brand-orange font-bold text-[10px] bg-brand-orange-light px-1.5 py-0.5 rounded shrink-0 mt-0.5">
                        {note.timeStamp}
                      </span>
                      <p className="text-slate-600">
                        <span className="font-semibold text-brand-navy">{note.author}: </span>
                        {note.text}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

          {/* Operational helper explanation */}
          <div className="rounded-xl bg-[#FFF9F0] border border-brand-orange/20 p-4 flex gap-3 text-brand-slate text-xs leading-relaxed">
            <span className="h-5 w-5 rounded-full bg-brand-orange/20 text-brand-orange flex items-center justify-center shrink-0 font-bold font-mono">i</span>
            <div>
              <span className="font-semibold text-brand-navy block mb-0.5">Brand Transition Audit Verified:</span> 
              This interface demonstrates the new approved colors exactly. The original teal background is now a robust deep navy, individual rows links are soft primary orange and high contrast gray headers are completely brand complaint.
            </div>
          </div>

        </main>
      </div>

      {/* 5. METRICS FOOTER */}
      <div className="bg-brand-navy px-5 py-3.5 flex flex-wrap gap-4 items-center justify-between text-xs text-slate-400 border-t border-brand-navy-light/20">
        <div className="flex items-center gap-2">
          <Lock className="h-3.5 w-3.5 text-brand-orange" />
          <span className="text-slate-300 font-semibold text-xs">Secure True Pro Workspace</span>
        </div>
        <div className="text-[11px] text-slate-300 font-mono">
          Last Database Sync: Just now
        </div>
      </div>
    </div>
  );
}

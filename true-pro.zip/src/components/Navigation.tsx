import { useState, useEffect } from 'react';
import { Menu, X, ArrowRight, ShieldCheck } from 'lucide-react';

interface NavigationProps {
  onBookDemo: () => void;
  scrollToSection: (id: string) => void;
}

export default function Navigation({ onBookDemo, scrollToSection }: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/95 backdrop-blur-md shadow-sm border-b border-brand-slate-light py-3' 
          : 'bg-white/40 backdrop-blur-xs py-5'
      }`}
      id="truepro-main-navigation-header"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Logo */}
          <div 
            className="flex items-center gap-2 cursor-pointer group" 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            id="nav-logo"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-navy group-hover:bg-brand-orange transition-colors duration-300 shadow-sm">
              <span className="font-display text-lg font-black text-white italic tracking-tighter">TP</span>
            </div>
            <div>
              <span className="font-display text-xl font-bold tracking-tight text-brand-navy">
                True<span className="text-brand-orange">Pro</span>
              </span>
              <span className="block text-[9px] font-mono tracking-wider text-brand-slate uppercase font-semibold leading-none">
                Field Software
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8" id="desktop-menu">
            <button 
              onClick={() => scrollToSection('features')}
              className="text-sm font-semibold text-brand-slate hover:text-brand-navy transition-colors cursor-pointer"
            >
              Features
            </button>
            <button 
              onClick={() => scrollToSection('industries')}
              className="text-sm font-semibold text-brand-slate hover:text-brand-navy transition-colors cursor-pointer"
            >
              Industries
            </button>
            <button 
              onClick={() => scrollToSection('how-it-helps')}
              className="text-sm font-semibold text-brand-slate hover:text-brand-navy transition-colors cursor-pointer"
            >
              Solutions
            </button>
            <a 
              href="#pricing"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('final-cta');
              }}
              className="text-sm font-semibold text-brand-slate hover:text-brand-navy transition-colors"
            >
              Pricing
            </a>
          </nav>

          {/* CTA Group */}
          <div className="hidden md:flex items-center gap-4" id="desktop-cta">
            <button 
              onClick={onBookDemo}
              className="px-5 py-2.5 rounded-xl bg-brand-navy text-xs font-bold text-white shadow-sm hover:bg-brand-orange transition-all duration-300 flex items-center gap-1 cursor-pointer"
              id="header-cta-book-demo"
            >
              Book a Demo
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="rounded-lg p-2 text-brand-navy hover:bg-slate-100 transition-colors"
              aria-label="Toggle Menu"
              id="mobile-menu-toggle"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {isOpen && (
        <div className="md:hidden bg-white border-b border-slate-100 shadow-inner px-4 pt-2 pb-6 space-y-3" id="mobile-menu-dropdown">
          <button 
            onClick={() => {
              setIsOpen(false);
              scrollToSection('features');
            }}
            className="block w-full text-left py-2 text-sm font-semibold text-brand-slate hover:text-brand-navy transition-colors"
          >
            Features
          </button>
          <button 
            onClick={() => {
              setIsOpen(false);
              scrollToSection('industries');
            }}
            className="block w-full text-left py-2 text-sm font-semibold text-brand-slate hover:text-brand-navy transition-colors"
          >
            Industries
          </button>
          <button 
            onClick={() => {
              setIsOpen(false);
              scrollToSection('how-it-helps');
            }}
            className="block w-full text-left py-2 text-sm font-semibold text-brand-slate hover:text-brand-navy transition-colors"
          >
            Solutions
          </button>
          <button 
            onClick={() => {
              setIsOpen(false);
              scrollToSection('final-cta');
            }}
            className="block w-full text-left py-2 text-sm font-semibold text-brand-slate hover:text-brand-navy transition-colors"
          >
            Pricing
          </button>
          <div className="border-t border-slate-100 pt-3">
            <button
              onClick={() => {
                setIsOpen(false);
                onBookDemo();
              }}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-brand-orange py-2.5 text-xs font-bold text-white shadow-md hover:bg-brand-orange-hover"
              id="mobile-cta-book-demo"
            >
              Book a Demo
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
}

import { CalendarCheck, ArrowRight, ShieldCheck, Mail, Map, Users } from 'lucide-react';

interface CTASectionProps {
  onBookDemo: () => void;
}

export default function CTASection({ onBookDemo }: CTASectionProps) {
  return (
    <section className="py-24 bg-brand-navy text-white relative" id="final-cta">

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10 space-y-8">
        
        <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-orange-light/10 text-brand-orange mb-2">
          <CalendarCheck className="h-6 w-6" />
        </div>

        <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-black tracking-tight max-w-3xl mx-auto leading-tight">
          Ready to bring more control to your operation?
        </h2>
        
        <p className="text-slate-300 text-sm sm:text-base md:text-lg max-w-2xl mx-auto leading-relaxed">
          See how True Pro helps outdoor service teams organize jobs, crews, customers, and follow-up from one connected platform.
        </p>

        {/* CTAs */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onBookDemo}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-brand-orange hover:bg-brand-orange-hover text-sm font-bold text-white shadow-lg transition-all hover:scale-[1.01] cursor-pointer flex items-center justify-center gap-2"
            id="cta-bottom-book"
          >
            Book a Demo
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        {/* Rejection / Alternatives information */}
        <div className="pt-8 border-t border-brand-navy-light/40 max-w-lg mx-auto grid grid-cols-3 gap-2 sm:gap-4 text-center">
          <div className="space-y-1">
            <span className="block text-white font-mono text-sm sm:text-base font-bold">1:1 Demo</span>
            <span className="block text-slate-400 text-[10px] uppercase font-semibold">Live Training</span>
          </div>
          <div className="space-y-1 border-x border-brand-navy-light/40">
            <span className="block text-white font-mono text-sm sm:text-base font-bold">15 Mins</span>
            <span className="block text-slate-400 text-[10px] uppercase font-semibold">Quick Walkthrough</span>
          </div>
          <div className="space-y-1">
            <span className="block text-white font-mono text-sm sm:text-base font-bold">Zero Hassle</span>
            <span className="block text-slate-400 text-[10px] uppercase font-semibold">No Pressure Calls</span>
          </div>
        </div>

        {/* Guarantee Seal */}
        <p className="text-xs text-slate-400 pt-2 flex items-center justify-center gap-1.5">
          <ShieldCheck className="h-4 w-4 text-brand-orange" /> Built for field companies, office managers, and ambitious business owners.
        </p>

      </div>
    </section>
  );
}
